"""Eigen-CAM sign-ambiguity check on the PRELIMINARY model (validation split).
The first singular vector has an arbitrary sign; we align it to the mean activation energy and
report how often it had to be flipped, plus border/core saliency ratios per class."""
import argparse, glob, os
from collections import defaultdict

import cv2
import numpy as np
import torch
from numpy.linalg import svd
from ultralytics import YOLO

NAMES = ["Controlo", "HTO", "PAOG", "PAOG Suspect"]
ap = argparse.ArgumentParser()
ap.add_argument("--weights", required=True, help="best.pt of the preliminary (fixed-box) model")
ap.add_argument("--data-root", default="data/papila_split")
ap.add_argument("--layer", type=int, default=15)
ap.add_argument("--save-dir", default="results/cam")
a = ap.parse_args()

model = YOLO(a.weights)
net = model.model.eval()
device = next(net.parameters()).device
acts = {}
net.model[a.layer].register_forward_hook(lambda m, i, o: acts.__setitem__("v", o.detach()))
flips = []


def cam(t, size=(640, 640)):
    with torch.no_grad():
        net(t)
    act = acts["v"].squeeze(0).cpu().numpy()
    energy = np.abs(act).mean(axis=0).reshape(-1)
    flat = act.reshape(act.shape[0], -1).T
    flat = flat - flat.mean(axis=0)
    U, S, VT = svd(flat, full_matrices=False)
    comp = U[:, 0].copy()
    neg = np.corrcoef(comp, energy)[0, 1] < 0
    flips.append(bool(neg))
    if neg:
        comp = -comp
    sal = np.maximum(comp.reshape(act.shape[1], act.shape[2]), 0)
    sal = (sal - sal.min()) / (sal.max() - sal.min() + 1e-8)
    return cv2.resize(sal, size)


def border_core(rgb, sal, bw=25):
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    ret = (gray > 15).astype(np.uint8)
    dist = cv2.distanceTransform(ret, cv2.DIST_L2, 5)
    b, c = (dist > 0) & (dist <= bw), dist > bw
    if b.sum() == 0 or c.sum() == 0:
        return None
    return sal[b].mean() / (sal[c].mean() + 1e-8)


def tensor(rgb):
    return torch.from_numpy(np.float32(rgb) / 255.0).permute(2, 0, 1).unsqueeze(0).to(device)


vdir = a.data_root + "/valid"
ratios = defaultdict(list)
os.makedirs(a.save_dir, exist_ok=True)
for lp in sorted(glob.glob(vdir + "/labels/*.txt")):
    with open(lp) as f:
        cid = int(f.readline().split()[0])
    eid = os.path.basename(lp).rsplit(".", 1)[0]
    rgb = cv2.cvtColor(cv2.resize(cv2.imread(f"{vdir}/images/{eid}.jpg"), (640, 640)), cv2.COLOR_BGR2RGB)
    sal = cam(tensor(rgb))
    r = border_core(rgb, sal)
    if r is not None:
        ratios[NAMES[cid]].append(r)
    heat = cv2.cvtColor(cv2.applyColorMap(np.uint8(255 * sal), cv2.COLORMAP_JET), cv2.COLOR_BGR2RGB)
    ov = np.uint8(0.6 * rgb + 0.4 * heat)
    cv2.imwrite(f"{a.save_dir}/{NAMES[cid].replace(' ', '_')}_{eid}.jpg", cv2.cvtColor(ov, cv2.COLOR_RGB2BGR))

print("fraction of images whose component sign had to be flipped:", round(float(np.mean(flips)), 2))
for c, v in ratios.items():
    v = np.array(v)
    print(c, "n=", len(v), "median border/core=", round(float(np.median(v)), 2),
          "% > 1:", round(100 * float((v > 1).mean()), 1))
