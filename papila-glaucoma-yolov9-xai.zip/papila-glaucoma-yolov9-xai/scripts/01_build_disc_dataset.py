"""FINAL model dataset: expert optic-disc box x1.3, PATIENT-level stratified split (seed 42),
minority-class oversampling in train only. Expected: 488 eyes (312/21/87/68), split 344/72/72."""
import argparse, glob, math, os, random, shutil, sys
from collections import Counter, defaultdict

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from papila_common import CLASS_NAMES, SEV, disc_box, eye_labels, image_entries, open_papila

ap = argparse.ArgumentParser()
ap.add_argument("--zip", default="data/papila.zip")
ap.add_argument("--out", default="data/papila_disc")
ap.add_argument("--width", type=int, default=800)
ap.add_argument("--pad", type=float, default=1.3)
ap.add_argument("--target", type=int, default=100, help="oversample each train class up to ~this many")
a = ap.parse_args()
ROOT = os.path.abspath(a.out)

z = open_papila(a.zip)
labels = eye_labels(z)
entries = image_entries(z)

if os.path.exists(ROOT):
    shutil.rmtree(ROOT)
os.makedirs(ROOT + "/all/images")
os.makedirs(ROOT + "/all/labels")

valid = {}
for eid, c in labels.items():
    if eid not in entries:
        continue
    img = cv2.imdecode(np.frombuffer(z.read(entries[eid]), np.uint8), cv2.IMREAD_COLOR)
    H, W = img.shape[:2]
    box = disc_box(z, eid, W, H, a.pad)
    if box is None:
        continue
    small = cv2.resize(img, (a.width, int(round(H * a.width / W))))
    cv2.imwrite(f"{ROOT}/all/images/{eid}.jpg", small)
    with open(f"{ROOT}/all/labels/{eid}.txt", "w") as f:
        f.write("%d %.6f %.6f %.6f %.6f\n" % ((CLASS_NAMES.index(c),) + box))
    valid[eid] = c
print("Eyes with disc box:", len(valid), dict(Counter(valid.values())))

# patient-level split: a patient's label = most severe eye; both eyes always in the same split
pats = defaultdict(list)
for eid in valid:
    pats[eid[3:6]].append(eid)
plabel = {p: max((valid[e] for e in es), key=lambda c: SEV[c]) for p, es in pats.items()}

random.seed(42)
by_class = defaultdict(list)
for p, c in plabel.items():
    by_class[c].append(p)
split_of = {}
for c, plist in by_class.items():
    plist = sorted(plist)
    random.shuffle(plist)
    n = len(plist)
    nt = max(1, round(n * 0.15))
    nv = max(1, round(n * 0.15))
    for p in plist[:nt]:
        split_of[p] = "test"
    for p in plist[nt:nt + nv]:
        split_of[p] = "valid"
    for p in plist[nt + nv:]:
        split_of[p] = "train"

for sp in ("train", "valid", "test"):
    os.makedirs(f"{ROOT}/{sp}/images")
    os.makedirs(f"{ROOT}/{sp}/labels")

train_by_class = defaultdict(list)
for eid, c in valid.items():
    sp = split_of[eid[3:6]]
    shutil.copy(f"{ROOT}/all/images/{eid}.jpg", f"{ROOT}/{sp}/images/{eid}.jpg")
    shutil.copy(f"{ROOT}/all/labels/{eid}.txt", f"{ROOT}/{sp}/labels/{eid}.txt")
    if sp == "train":
        train_by_class[c].append(eid)

for c, eids in train_by_class.items():  # oversampling: TRAIN ONLY (copies named *_dupK)
    for k in range(1, max(1, math.ceil(a.target / len(eids)))):
        for eid in eids:
            shutil.copy(f"{ROOT}/all/images/{eid}.jpg", f"{ROOT}/train/images/{eid}_dup{k}.jpg")
            shutil.copy(f"{ROOT}/all/labels/{eid}.txt", f"{ROOT}/train/labels/{eid}_dup{k}.txt")

for sp in ("train", "valid", "test"):
    cnt = Counter()
    for lp in glob.glob(f"{ROOT}/{sp}/labels/*.txt"):
        with open(lp) as f:
            cnt[CLASS_NAMES[int(f.readline().split()[0])]] += 1
    print(sp, dict(cnt))

with open(f"{ROOT}/data.yaml", "w") as f:
    f.write(f"train: {ROOT}/train/images\nval: {ROOT}/valid/images\ntest: {ROOT}/test/images\n\n"
            f"nc: 4\nnames: {CLASS_NAMES}\n")
print("data.yaml written to", ROOT)
