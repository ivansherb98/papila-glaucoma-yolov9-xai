"""Train the final YOLOv9c disc-anchored model (COCO-pretrained yolov9c.pt)."""
import argparse
from ultralytics import YOLO

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/papila_disc/data.yaml")
ap.add_argument("--project", default="runs")
ap.add_argument("--name", default="disc_box")
a = ap.parse_args()

m = YOLO("yolov9c.pt")
m.train(data=a.data, epochs=80, imgsz=640, patience=30, batch=8, workers=1, cache=False,
        save_period=10, project=a.project, name=a.name, exist_ok=True, seed=0)
