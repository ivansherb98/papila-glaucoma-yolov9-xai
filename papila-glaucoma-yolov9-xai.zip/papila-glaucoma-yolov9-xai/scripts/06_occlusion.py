"""Occlusion test on the PRELIMINARY model (valid+test splits): drop in true-class confidence when
(a) the expert-annotated optic disc, (b) an equal-area random retinal disc away from the optic
disc, or (c) the peripheral 25-px border is replaced by the mean retinal colour."""
import argparse, glob, os, sys
import cv2
import numpy as np
from ultralytics import YOLO

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from papila_common import BASE, CLASS_NAMES, open_papila

ap = argparse.ArgumentParser()
ap.add_argument("--weights", required=True)
ap.add_argument("--zip", default="data/papila.zip")
ap.add_argument("--data-root", default="data/papila_split")
a = ap.parse_args()

model = YOLO(a.weights)
z = open_papila(a.zip)
rng = np.random.default_rng(0)


def true_conf(img, cid):
    b = model.predict(img, imgsz=640, conf=0.001, verbose=False)[0].boxes
    if b is None or len(b) == 0:
        return 0.0
    cls, conf = b.cls.cpu().numpy().astype(int), b.conf.cpu().numpy()
    return float(conf[cls == cid].max()) if (cls == cid).any() else 0.0


def disc_mask(eid, W, H):
    try:
        pts = np.loadtxt(z.open(BASE + "ExpertsSegmentations/Contours/" + eid + "_disc_exp1.txt")).copy()
    except KeyError:
        return None
    pts[:, 0] *= 640.0 / W
    pts[:, 1] *= 640.0 / H
    m = np.zeros((640, 640), np.uint8)
    cv2.fillPoly(m, [pts.astype(np.int32)], 1)
    return m


def occlude(img, mask, color):
    out = img.copy()
    out[mask > 0] = color
    return out


rows = []
for split in ("valid", "test"):
    d = f"{a.data_root}/{split}"
    for lp in sorted(glob.glob(d + "/labels/*.txt")):
        with open(lp) as f:
            cid = int(f.readline().split()[0])
        eid = os.path.basename(lp).rsplit(".", 1)[0]
        orig = cv2.imread(f"{d}/images/{eid}.jpg")
        H, W = orig.shape[:2]
        img = cv2.resize(orig, (640, 640))
        dm = disc_mask(eid, W, H)
        if dm is None or dm.sum() < 50:
            continue
        ret = (cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) > 15).astype(np.uint8)
        dist = cv2.distanceTransform(ret, cv2.DIST_L2, 5)
        border = ((dist > 0) & (dist <= 25)).astype(np.uint8)
        color = img[ret > 0].mean(axis=0).astype(np.uint8)
        r = int(np.sqrt(dm.sum() / np.pi))
        ys, xs = np.where(dist > r + 25)
        ctrl = None
        for _ in range(100):
            if len(ys) == 0:
                break
            k = rng.integers(len(ys))
            t = np.zeros((640, 640), np.uint8)
            cv2.circle(t, (int(xs[k]), int(ys[k])), r, 1, -1)
            if (t & dm).sum() < 0.1 * t.sum():
                ctrl = t
                break
        if ctrl is None:
            continue
        rows.append((CLASS_NAMES[cid], true_conf(img, cid), true_conf(occlude(img, dm, color), cid),
                     true_conf(occlude(img, ctrl, color), cid), true_conf(occlude(img, border, color), cid)))

print("n images:", len(rows))
A = np.array([r[1:] for r in rows])
print("mean baseline confidence:", round(A[:, 0].mean(), 3))
print("drop when occluding DISC:", round((A[:, 0] - A[:, 1]).mean(), 3))
print("drop when occluding equal-area RETINA control:", round((A[:, 0] - A[:, 2]).mean(), 3))
print("drop when occluding peripheral BORDER:", round((A[:, 0] - A[:, 3]).mean(), 3))
for c in CLASS_NAMES:
    S = np.array([r[1:] for r in rows if r[0] == c])
    if len(S):
        print(c, "n=", len(S), "disc:", round((S[:, 0] - S[:, 1]).mean(), 3),
              "control:", round((S[:, 0] - S[:, 2]).mean(), 3), "border:", round((S[:, 0] - S[:, 3]).mean(), 3))
