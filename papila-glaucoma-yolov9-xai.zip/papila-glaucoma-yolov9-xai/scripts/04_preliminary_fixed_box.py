"""PRELIMINARY experiment (kept for transparency): whole-image box (0.5 0.5 0.98 0.98) and an
EYE-LEVEL stratified split (seed 42) -> 342/73/73. NOTE: both eyes of one patient can fall in
different splits (no patient-level separation). Used only for the exploratory XAI analyses
(Eigen-CAM sign check, occlusion); it is NOT the model whose test results are reported."""
import argparse, os, random, shutil, sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from papila_common import CLASS_NAMES, eye_labels, image_entries, open_papila

ap = argparse.ArgumentParser()
ap.add_argument("--zip", default="data/papila.zip")
ap.add_argument("--out", default="data/papila_split")
ap.add_argument("--train", action="store_true", help="also train (100 epochs, imgsz 640)")
a = ap.parse_args()
ROOT = os.path.abspath(a.out)

z = open_papila(a.zip)
labels = eye_labels(z)
entries = image_entries(z)
labels = {e: c for e, c in labels.items() if e in entries}
print("eyes:", len(labels), dict(Counter(labels.values())))

random.seed(42)
by_class = defaultdict(list)
for e, c in labels.items():
    by_class[c].append(e)
split = {}
for c, ids in by_class.items():
    ids = sorted(ids)
    random.shuffle(ids)
    n = len(ids)
    nt = max(1, round(n * 0.15))
    nv = max(1, round(n * 0.15))
    for e in ids[:nt]:
        split[e] = "test"
    for e in ids[nt:nt + nv]:
        split[e] = "valid"
    for e in ids[nt + nv:]:
        split[e] = "train"

for sp in ("train", "valid", "test"):
    os.makedirs(f"{ROOT}/{sp}/images", exist_ok=True)
    os.makedirs(f"{ROOT}/{sp}/labels", exist_ok=True)
for e, c in labels.items():
    sp = split[e]
    with open(f"{ROOT}/{sp}/images/{e}.jpg", "wb") as dst:
        dst.write(z.read(entries[e]))
    with open(f"{ROOT}/{sp}/labels/{e}.txt", "w") as f:
        f.write(f"{CLASS_NAMES.index(c)} 0.5 0.5 0.98 0.98\n")
print({sp: sum(1 for v in split.values() if v == sp) for sp in ("train", "valid", "test")}, "(expected 342/73/73)")
with open(f"{ROOT}/data.yaml", "w") as f:
    f.write(f"train: {ROOT}/train/images\nval: {ROOT}/valid/images\ntest: {ROOT}/test/images\n\n"
            f"nc: 4\nnames: {CLASS_NAMES}\n")

if a.train:
    from ultralytics import YOLO
    YOLO("yolov9c.pt").train(data=f"{ROOT}/data.yaml", epochs=100, imgsz=640, patience=20, batch=8,
                             workers=2, cache="disk", project="runs", name="papila_yolov9c")
