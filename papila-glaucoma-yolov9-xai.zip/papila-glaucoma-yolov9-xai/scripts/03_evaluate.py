"""Test-set evaluation: confusion matrix (top-confidence detection = predicted class),
accuracy, balanced accuracy and a stratified bootstrap 95% CI (20,000 resamples)."""
import argparse, glob, os
import numpy as np

NAMES = ["Controlo", "HTO", "PAOG", "PAOG Suspect"]


def balanced_accuracy(cm):
    return float(np.mean([cm[i, i] / max(1, cm[i].sum()) for i in range(4)]))


def bootstrap_ci(cm, n_boot=20000, seed=0):
    """Resample test eyes within each true class (stratified); per-class recall ~ Binomial(n_c, r_c)."""
    rng = np.random.default_rng(seed)
    n = cm[:, :].sum(axis=1)
    p = np.array([cm[i, i] / max(1, n[i]) for i in range(4)])
    ba = np.mean([rng.binomial(n[i], p[i], n_boot) / max(1, n[i]) for i in range(4)], axis=0)
    return np.percentile(ba, [2.5, 97.5])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default="runs/disc_box/weights/best.pt")
    ap.add_argument("--data-root", default="data/papila_disc")
    a = ap.parse_args()

    from ultralytics import YOLO
    mdl = YOLO(a.weights)
    cm = np.zeros((4, 5), int)  # rows: true class; cols: 4 classes + 'no detection'
    for lp in sorted(glob.glob(a.data_root + "/test/labels/*.txt")):
        with open(lp) as f:
            cid = int(f.readline().split()[0])
        img = a.data_root + "/test/images/" + os.path.basename(lp).rsplit(".", 1)[0] + ".jpg"
        res = mdl.predict(img, imgsz=640, conf=0.001, verbose=False)[0]
        if len(res.boxes) == 0:
            cm[cid, 4] += 1
        else:
            cm[cid, int(res.boxes.cls[int(res.boxes.conf.argmax())])] += 1
    print("rows = true; cols =", NAMES + ["no detection"])
    print(cm)
    rec = [cm[i, i] / max(1, cm[i].sum()) for i in range(4)]
    print("recall per class:", [round(x, 2) for x in rec])
    print("accuracy:", round(float(np.trace(cm[:, :4]) / cm.sum()), 3),
          "| always-Controlo baseline:", round(float(cm[0].sum() / cm.sum()), 3))
    lo, hi = bootstrap_ci(cm)
    print(f"balanced accuracy: {balanced_accuracy(cm):.3f} (95% CI {lo:.2f}-{hi:.2f}; chance 0.25)")
