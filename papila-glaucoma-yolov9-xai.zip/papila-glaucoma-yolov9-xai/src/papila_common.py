"""Shared helpers: PAPILA download, label derivation, optic-disc boxes."""
import io
import os
import zipfile

import numpy as np
import openpyxl
import requests

CLASS_NAMES = ["Controlo", "HTO", "PAOG", "PAOG Suspect"]  # = Control, OHT, POAG, POAG suspect
SEV = {"Controlo": 0, "HTO": 1, "PAOG Suspect": 2, "PAOG": 3}  # patient label = most severe eye
PAPILA_URL = "https://ndownloader.figshare.com/files/35013982"  # figshare article 14798004
BASE = "PapilaDB-PAPILA-17f8fa7746adb20275b5b6a0d99dc9dfe3007e9f/"


def download_papila(zip_path):
    """Download PAPILA (CC BY 4.0, ~591 MB) if not already present."""
    if os.path.exists(zip_path):
        return
    os.makedirs(os.path.dirname(os.path.abspath(zip_path)), exist_ok=True)
    r = requests.get(PAPILA_URL, stream=True, timeout=60)
    r.raise_for_status()
    with open(zip_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024 * 1024):
            f.write(chunk)


def _load_sheet(z, fname):
    wb = openpyxl.load_workbook(io.BytesIO(z.read(BASE + "ClinicalData/" + fname)))
    ws = wb.active
    return [row for row in ws.iter_rows(min_row=3, values_only=True) if row[0] is not None]


def derive_class(diagnosis, pneumatic, perkins):
    """Diagnosis 0=healthy, 1=glaucoma, 2=suspect (PAPILA).
    OHT is a PROXY: healthy diagnosis + pneumatic or Perkins IOP > 21 mmHg."""
    if diagnosis is None:
        return None
    if diagnosis == 1:
        return "PAOG"
    if diagnosis == 2:
        return "PAOG Suspect"
    if diagnosis == 0:
        a = pneumatic or 0
        b = perkins or 0
        return "HTO" if (a > 21 or b > 21) else "Controlo"
    return None


def eye_labels(z):
    """{'RET002OD': 'Controlo', ...}; rows without a diagnosis are skipped (2 in PAPILA)."""
    out = {}
    for fname, suf in [("patient_data_od.xlsx", "OD"), ("patient_data_os.xlsx", "OS")]:
        for r in _load_sheet(z, fname):
            pid = str(r[0]).replace("#", "").strip().zfill(3)
            c = derive_class(r[3], r[8], r[9])
            if c:
                out["RET" + pid + suf] = c
    return out


def image_entries(z):
    return {os.path.basename(n).rsplit(".", 1)[0]: n
            for n in z.namelist()
            if "FundusImages/" in n and n.lower().endswith((".jpg", ".jpeg", ".png"))}


def disc_box(z, eid, W, H, pad=1.3):
    """Union of both experts' optic-disc contours, enlarged by `pad`, clamped to the image.
    Returns normalised YOLO (xc, yc, w, h) or None."""
    xs, ys = [], []
    for exp in ("exp1", "exp2"):
        name = BASE + "ExpertsSegmentations/Contours/" + eid + "_disc_" + exp + ".txt"
        try:
            pts = np.loadtxt(io.BytesIO(z.read(name)))
        except KeyError:
            continue
        xs.extend(pts[:, 0].tolist())
        ys.extend(pts[:, 1].tolist())
    if not xs:
        return None
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    w, h = (x1 - x0) * pad, (y1 - y0) * pad
    x0, x1 = max(0, cx - w / 2), min(W, cx + w / 2)
    y0, y1 = max(0, cy - h / 2), min(H, cy + h / 2)
    return ((x0 + x1) / 2 / W, (y0 + y1) / 2 / H, (x1 - x0) / W, (y1 - y0) / H)


def open_papila(zip_path):
    download_papila(zip_path)
    return zipfile.ZipFile(zip_path, "r")
