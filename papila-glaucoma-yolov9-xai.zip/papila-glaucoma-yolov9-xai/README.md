# Explainability audit of multi-stage glaucoma detection with YOLOv9 (PAPILA)

Code for the EVER 2026 rapid-fire talk / poster *(Shcherbinin I., Faculty of Medicine, University of Coimbra; T.BIO)*.
A YOLOv9c detector is used as a **detection-based classifier** of four classes on the public
[PAPILA](https://doi.org/10.1038/s41597-022-01388-1) fundus dataset (CC BY 4.0, figshare
[14798004](https://figshare.com/articles/dataset/PAPILA/14798004)), and the explanations
(Eigen-CAM, occlusion) are **audited** instead of being taken at face value.

> **This is a research audit, not a diagnostic tool.** It must not be used for clinical decisions.

## Classes (names kept in Portuguese for compatibility with the original labels)
`Controlo` (control) · `HTO` (ocular hypertension) · `PAOG` (primary open-angle glaucoma) · `PAOG Suspect` (glaucoma suspect).
**HTO is a proxy**: PAPILA diagnosis "healthy" with pneumatic *or* Perkins IOP > 21 mmHg. It is not a clinical OHT diagnosis
(single measurements). Only 21 eyes qualify (2 in the test set), so HTO is **not evaluable** here.

## Headline result (final disc-anchored model, test set, 72 eyes)
|  | Controlo | HTO | PAOG | PAOG Suspect |
|---|---|---|---|---|
| n (test eyes) | 46 | 2 | 14 | 10 |
| recall | 0.80 | 0.00 | 0.21 | 0.30 |

Balanced accuracy **0.33** (95 % CI 0.24–0.43; chance = 0.25). Accuracy 60 % vs 64 % for always predicting *Controlo*.
Confusion matrix: [`results/test_confusion_matrix.csv`](results/test_confusion_matrix.csv).
The model is close to chance and this is reported as such: the contribution is the audit, not the accuracy.

## Reproduce
```bash
pip install -r requirements.txt          # GPU strongly recommended
python scripts/01_build_disc_dataset.py  # downloads PAPILA (~591 MB), builds boxes + patient-level split
python scripts/02_train_disc.py          # 80 epochs, imgsz 640, batch 8, seed 0 (~50 min on a T4)
python scripts/03_evaluate.py            # confusion matrix, balanced accuracy, bootstrap CI
```
Expected after step 1: 488 labelled eyes (Controlo 312, HTO 21, PAOG 87, Suspect 68; 2 eyes without diagnosis are skipped);
split 344 / 72 / 72 (train includes oversampled copies of minority classes, train only).
GPU training is not bit-for-bit deterministic; small differences from the reported numbers are expected.

### Final model
* Box = union of the two experts' optic-disc contours × 1.3 (so the box is anchored on the optic nerve head).
* **Patient-level** stratified split (seed 42, 15 %/15 %); a patient's stratum = most severe eye; both eyes always share a split.
* Minority-class oversampling (to ≈100 per class) applied to the training split only.
* Prediction = class of the highest-confidence detection (`conf=0.001`).
* Bootstrap CI: 20,000 stratified resamples of test eyes within each true class (`scripts/03_evaluate.py`).

### Preliminary (exploratory) model — please read
The XAI analyses (Eigen-CAM sign check, occlusion) were run on an earlier model trained with a whole-image box
(`0.5 0.5 0.98 0.98`) and an **eye-level** split (342/73/73; both eyes of one patient may fall in different splits, i.e. no
patient-level separation). Its metrics are **not** reported as performance. The XAI results describe model behaviour on those
images only. Scripts: `04_preliminary_fixed_box.py`, `05_eigencam_sign_check.py`, `06_occlusion.py`.
```bash
python scripts/04_preliminary_fixed_box.py --train
python scripts/05_eigencam_sign_check.py --weights runs/papila_yolov9c/weights/best.pt
python scripts/06_occlusion.py            --weights runs/papila_yolov9c/weights/best.pt
```
Findings: Eigen-CAM's first component has an arbitrary sign (44 % of images had to be flipped to match activation energy);
saliency concentrates on the image border (border/core > 1 in 100 % of images); occluding the optic disc reduced
true-class confidence by 0.105 versus 0.021 for an equal-area retinal control and −0.002 for the periphery (n = 146).

## What is NOT in this repository
* No data. PAPILA must be downloaded from figshare (CC BY 4.0) — please cite Kovalyk et al., *Sci Data* 2022.
* No weights (`*.pt` is git-ignored). Weights trained on PAPILA can be attached to a release if desired.
* No code or data from earlier work on a different, private clinical dataset; nothing here depends on it.
* The cup-to-disc correlation analysis is not included.

## Limitations
Small single-centre dataset (488 eyes / ~300 patients); HTO is a proxy and not evaluable; test set of
72 eyes (very wide CIs); heatmaps are post-hoc and unreliable as evidence of clinical reasoning (see audit); not externally validated.

## Licence
AGPL-3.0 (this code builds on [Ultralytics](https://github.com/ultralytics/ultralytics), AGPL-3.0). PAPILA data keep their own CC BY 4.0 licence.

## Citation
See [`CITATION.cff`](CITATION.cff) (GitHub shows a "Cite this repository" button) or the Zenodo DOI once released.
